<?php get_header(); ?>

<!-- 1. AUTO-SCROLLING TEXT TICKER (Green Bar, White Text) -->
  <section class="ticker-bar" aria-label="Latest Updates Ticker">
    <div class="ticker-wrap">
      <div class="ticker-track">
        <span class="ticker-item"><span class="ticker-bullet">★</span>Hiring Sales Executives in Bhubaneswar</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Verified drivers across Odisha</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>House help &amp; cooks on request</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Back-office staff for your business</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Pandit booking for pujas</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Call for a free consultation</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Serving Bhubaneswar, Cuttack, Puri, Rourkela, Sambalpur, Berhampur &amp; more</span>
        <!-- Duplicate for continuous loop -->
        <span class="ticker-item"><span class="ticker-bullet">★</span>Hiring Sales Executives in Bhubaneswar</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Verified drivers across Odisha</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>House help &amp; cooks on request</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Back-office staff for your business</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Pandit booking for pujas</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Call for a free consultation</span>
        <span class="ticker-item"><span class="ticker-bullet">★</span>Serving Bhubaneswar, Cuttack, Puri, Rourkela, Sambalpur, Berhampur &amp; more</span>
      </div>
    </div>
  </section>

  <!-- 2. HERO SECTION -->
  <section class="hero-section" id="heroSection">
    <div class="hero-bg-layer" id="heroBgLayer" aria-hidden="true"></div>
    <div class="hero-parallax-shapes" aria-hidden="true">
      <div class="parallax-orb orb-1" data-speed="0.06"></div>
      <div class="parallax-orb orb-2" data-speed="-0.04"></div>
      <div class="parallax-orb orb-3" data-speed="0.08"></div>
    </div>
    <div class="container hero-grid">
      <div class="hero-content">
        <span class="section-badge">🇮🇳 100% Dedicated to Odisha</span>
        <h1 class="hero-headline">Odisha's Own Platform for <span class="highlight">Hiring, Jobs</span> &amp; Trusted Help</h1>
        <p class="hero-sub">Odiins connects businesses with the right people, job seekers with the right opportunity, and families with reliable help, all across Odisha.</p>
        
        <!-- 3 Big Green Buttons -->
        <div class="hero-buttons">
          <a href="<?php echo esc_url(home_url('/services-job-seekers/')); ?>" class="btn btn-green btn-lg">💼 I Need a Job</a>
          <a href="<?php echo esc_url(home_url('/services-employers/')); ?>" class="btn btn-green btn-lg">🏢 I Need Staff for My Business</a>
          <a href="<?php echo esc_url(home_url('/services-customers/')); ?>" class="btn btn-green btn-lg">🏠 I Need Help at Home</a>
        </div>

        <div class="hero-trust-line">
          <span>🛡️ Free enquiry</span>
          <span>•</span>
          <span>⚡ Quick response</span>
          <span>•</span>
          <span>🤝 Local Odisha team</span>
        </div>
      </div>

      <!-- Hero Visual (Right Side) -->
      <div class="hero-visual" id="heroVisual">
        <div class="hero-card-stack" id="heroCardStack">
          <div class="hero-badge-pill hero-badge-1" id="heroBadge1" data-depth="28">✓ Verified in Odisha</div>
          <div style="background:var(--bg-light-blue); border-radius:var(--radius-md); padding:0.5rem; text-align:center;">
            <!-- SVG Illustration: Odisha Map & Statewide People Network -->
            <svg viewBox="0 0 400 295" width="100%" height="auto" xmlns="http://www.w3.org/2000/svg" style="display:block;">
  <defs>
    <!-- Background Card Gradient -->
    <linearGradient id="cardBgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#F0F7FD"/>
      <stop offset="50%" stop-color="#FFFFFF"/>
      <stop offset="100%" stop-color="#EEF7F2"/>
    </linearGradient>

    <!-- Map Land Fill Gradient -->
    <linearGradient id="mapLandGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#E3F2FD" stop-opacity="0.9"/>
      <stop offset="50%" stop-color="#E8F5E9" stop-opacity="0.85"/>
      <stop offset="100%" stop-color="#D1EEDC" stop-opacity="0.95"/>
    </linearGradient>

    <!-- Network Hub Pulse Gradients -->
    <radialGradient id="hubPulseGrad" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#098B38" stop-opacity="0.55"/>
      <stop offset="60%" stop-color="#098B38" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#098B38" stop-opacity="0"/>
    </radialGradient>

    <radialGradient id="hubBluePulse" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#64A8DA" stop-opacity="0.6"/>
      <stop offset="60%" stop-color="#64A8DA" stop-opacity="0.2"/>
      <stop offset="100%" stop-color="#64A8DA" stop-opacity="0"/>
    </radialGradient>

    <!-- Soft Glow Filter -->
    <filter id="glowFilter" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="2" result="blur"/>
      <feComposite in="SourceGraphic" in2="blur" operator="over"/>
    </filter>

    <filter id="badgeShadow" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#0a2540" flood-opacity="0.15"/>
    </filter>

    <filter id="mapDropShadow" x="-10%" y="-10%" width="120%" height="125%">
      <feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#64A8DA" flood-opacity="0.2"/>
    </filter>
  </defs>

  <!-- Card Background -->
  <rect width="400" height="295" rx="16" fill="url(#cardBgGrad)"/>

  <!-- Subtle Network Grid Lines -->
  <g stroke="#D9E8F5" stroke-width="1" stroke-dasharray="3 4" opacity="0.5">
    <line x1="30" y1="65" x2="370" y2="65"/>
    <line x1="30" y1="125" x2="370" y2="125"/>
    <line x1="30" y1="185" x2="370" y2="185"/>
    <line x1="110" y1="25" x2="110" y2="235"/>
    <line x1="200" y1="25" x2="200" y2="235"/>
    <line x1="290" y1="25" x2="290" y2="235"/>
  </g>

  <!-- Bay of Bengal Coast Accent (Bottom-Right) -->
  <path d="M 265 145 C 295 160, 310 195, 340 215 L 365 215 C 365 170, 345 135, 305 110 Z" fill="#E1F0FA" opacity="0.6"/>
  <path d="M 290 165 Q 315 160 340 166 M 280 185 Q 310 178 335 185" stroke="#64A8DA" stroke-width="1.5" stroke-linecap="round" fill="none" opacity="0.4"/>

  <!-- EXACT ODISHA MAP OUTLINE (from User Uploaded Image) -->
  <g filter="url(#mapDropShadow)">
    <path d="M 267.4,22.0 L 269.1,23.2 L 270.3,25.6 L 274.4,26.1 L 275.5,27.2 L 277.9,27.4 L 281.4,32.0 L 284.4,33.6 L 284.7,32.6 L 287.1,31.7 L 288.7,33.6 L 290.6,33.6 L 291.4,34.7 L 293.3,34.9 L 294.1,36.6 L 294.7,36.3 L 295.2,37.1 L 297.2,37.6 L 296.7,39.2 L 297.1,40.6 L 300.1,40.1 L 300.8,41.9 L 302.0,42.8 L 307.6,43.3 L 310.2,45.4 L 310.8,47.6 L 309.4,50.0 L 309.4,51.6 L 310.6,53.1 L 312.8,53.1 L 312.9,51.0 L 315.5,50.1 L 316.0,48.0 L 317.4,48.7 L 319.0,48.7 L 320.2,50.5 L 319.4,51.9 L 321.0,55.7 L 328.2,57.1 L 329.4,59.1 L 330.1,64.7 L 326.0,67.7 L 320.3,67.4 L 314.7,69.6 L 307.5,75.9 L 303.7,81.6 L 302.6,84.5 L 303.1,88.3 L 308.8,99.2 L 309.4,101.0 L 308.6,103.2 L 309.8,102.6 L 311.3,105.9 L 312.6,106.2 L 302.0,113.9 L 301.3,115.7 L 300.2,116.4 L 299.7,119.7 L 301.5,120.4 L 302.0,119.1 L 303.1,120.0 L 301.5,123.2 L 299.0,125.0 L 299.1,125.7 L 297.4,127.2 L 292.4,129.5 L 286.1,137.8 L 285.6,140.5 L 284.4,141.5 L 281.7,142.0 L 275.0,145.3 L 264.9,147.7 L 254.7,151.5 L 241.4,158.5 L 232.2,165.3 L 228.7,169.3 L 225.2,171.4 L 219.1,177.3 L 215.7,182.8 L 212.6,181.1 L 212.8,179.3 L 211.9,179.3 L 211.4,180.7 L 209.0,180.9 L 209.8,182.3 L 211.6,182.4 L 211.3,183.8 L 209.6,183.9 L 207.9,185.5 L 207.4,183.6 L 205.2,184.5 L 203.3,187.2 L 201.7,186.6 L 202.1,189.5 L 198.7,193.1 L 197.5,192.4 L 198.6,193.8 L 197.5,195.1 L 197.6,195.8 L 196.5,196.3 L 195.2,196.1 L 194.2,196.9 L 192.5,196.1 L 186.5,198.3 L 183.3,195.5 L 180.4,195.8 L 179.3,195.0 L 178.2,195.5 L 176.1,193.5 L 175.6,192.4 L 175.9,191.1 L 174.8,190.8 L 174.3,187.5 L 173.3,186.6 L 171.8,187.5 L 173.7,190.2 L 172.8,191.2 L 171.6,190.0 L 171.0,187.8 L 170.0,187.3 L 170.0,186.5 L 170.7,186.2 L 169.4,185.6 L 166.6,180.7 L 165.6,181.3 L 166.2,182.4 L 165.1,183.2 L 165.1,184.3 L 163.6,184.7 L 162.8,186.6 L 160.9,186.3 L 160.7,185.4 L 161.6,184.5 L 159.9,184.3 L 160.5,186.7 L 159.4,187.0 L 159.9,188.9 L 159.2,189.5 L 157.1,187.2 L 155.7,187.4 L 154.6,186.6 L 153.5,187.8 L 154.4,189.3 L 154.6,188.5 L 155.6,188.9 L 156.4,190.6 L 155.3,190.8 L 156.3,190.9 L 156.7,191.3 L 156.2,191.8 L 157.8,192.9 L 156.6,195.0 L 154.1,195.2 L 153.5,196.3 L 151.9,196.7 L 151.7,197.9 L 149.8,197.9 L 149.0,199.9 L 147.1,197.9 L 146.5,198.3 L 145.8,197.4 L 145.1,197.8 L 144.0,200.3 L 144.9,200.6 L 146.0,200.1 L 146.4,201.9 L 145.5,203.1 L 144.2,202.9 L 144.0,204.9 L 142.9,206.0 L 142.9,207.0 L 144.0,208.1 L 141.8,211.9 L 142.8,213.1 L 143.6,212.8 L 144.2,214.0 L 142.5,215.5 L 140.6,215.3 L 137.9,216.6 L 135.8,216.4 L 134.8,215.3 L 134.9,213.9 L 133.8,214.2 L 131.4,212.8 L 130.8,213.5 L 131.3,214.3 L 131.0,216.4 L 130.2,217.5 L 127.7,218.5 L 127.1,219.3 L 126.0,219.3 L 125.0,220.5 L 125.0,221.6 L 123.8,222.3 L 121.8,220.5 L 122.1,219.2 L 121.6,218.4 L 122.3,217.5 L 122.3,215.9 L 119.7,214.8 L 120.5,213.0 L 119.4,213.0 L 118.9,211.9 L 119.1,209.9 L 118.4,210.1 L 117.1,208.7 L 112.9,213.7 L 113.7,215.9 L 112.1,218.1 L 113.6,218.0 L 113.9,218.9 L 113.0,220.3 L 111.6,220.8 L 111.3,223.2 L 110.5,224.1 L 112.9,226.4 L 112.5,227.1 L 111.6,226.8 L 111.8,230.2 L 110.6,231.2 L 109.3,230.4 L 108.6,230.7 L 108.4,233.6 L 104.6,232.5 L 103.9,230.9 L 102.5,231.2 L 101.7,230.4 L 100.1,230.1 L 94.4,233.6 L 88.5,235.8 L 87.6,237.2 L 85.3,238.6 L 85.2,238.8 L 84.2,239.3 L 83.6,238.4 L 82.5,238.4 L 81.8,240.0 L 80.1,241.5 L 78.2,240.9 L 74.4,242.0 L 73.6,240.9 L 72.0,241.2 L 71.1,242.0 L 69.9,241.6 L 70.5,237.8 L 72.7,237.8 L 72.7,235.9 L 74.0,234.0 L 74.0,230.7 L 74.8,230.0 L 75.9,226.2 L 75.9,225.4 L 75.1,224.8 L 75.9,221.6 L 79.3,218.7 L 81.5,218.5 L 82.0,217.1 L 85.4,216.9 L 86.1,214.0 L 89.9,210.5 L 90.6,209.0 L 92.1,208.3 L 92.8,206.9 L 93.9,207.1 L 94.2,206.5 L 91.5,204.6 L 91.5,203.2 L 91.9,202.8 L 93.9,203.6 L 94.6,201.6 L 95.5,200.9 L 97.9,199.9 L 99.8,200.1 L 99.9,198.3 L 101.9,197.9 L 103.2,196.7 L 103.2,193.2 L 103.7,192.2 L 105.7,190.9 L 106.7,191.1 L 106.2,186.7 L 104.8,184.8 L 105.3,183.4 L 104.4,182.0 L 103.6,182.3 L 103.2,181.6 L 103.7,179.1 L 102.9,178.4 L 102.6,175.4 L 104.0,172.4 L 102.4,171.6 L 102.4,170.5 L 103.7,170.2 L 104.0,168.4 L 101.4,168.2 L 99.8,164.2 L 99.0,164.7 L 97.2,164.6 L 98.0,163.2 L 97.5,160.5 L 98.3,159.2 L 97.8,155.1 L 98.5,151.9 L 95.5,151.5 L 94.1,148.5 L 89.7,146.5 L 89.2,143.8 L 89.9,140.8 L 90.6,139.5 L 91.2,139.9 L 93.9,137.2 L 97.4,140.6 L 99.0,139.3 L 104.1,142.6 L 106.2,141.7 L 107.8,142.9 L 110.6,149.0 L 113.3,146.6 L 115.2,145.8 L 116.0,146.3 L 117.3,146.0 L 118.7,147.1 L 121.7,147.4 L 121.7,151.5 L 122.7,151.2 L 124.1,149.3 L 126.3,149.3 L 126.7,148.3 L 126.1,146.7 L 126.6,142.2 L 123.3,142.0 L 121.7,142.6 L 120.0,141.5 L 117.9,141.5 L 112.9,139.4 L 112.3,134.5 L 113.4,133.5 L 113.4,129.5 L 114.3,128.9 L 113.9,127.5 L 112.9,126.8 L 112.9,125.7 L 114.3,122.1 L 113.7,121.8 L 113.9,120.9 L 112.7,121.3 L 112.3,119.1 L 109.6,116.4 L 111.6,113.2 L 111.6,111.6 L 110.5,110.0 L 110.0,104.8 L 110.5,101.6 L 111.2,101.2 L 111.7,102.0 L 113.3,102.3 L 114.1,103.9 L 115.2,103.9 L 116.4,102.6 L 116.4,100.5 L 119.0,99.0 L 121.8,95.4 L 122.3,94.3 L 121.8,92.7 L 123.2,91.6 L 122.7,89.7 L 123.0,89.0 L 128.2,88.5 L 129.5,89.3 L 131.7,88.3 L 133.8,88.8 L 134.4,88.3 L 135.4,88.5 L 137.1,87.2 L 138.8,88.3 L 138.5,89.3 L 139.2,89.0 L 142.0,90.6 L 144.2,90.9 L 145.5,89.6 L 146.7,89.4 L 147.8,83.8 L 150.2,82.7 L 149.1,81.6 L 150.1,78.5 L 154.1,79.9 L 155.6,79.7 L 155.1,77.5 L 153.2,75.4 L 152.6,72.9 L 154.0,70.5 L 154.0,68.4 L 156.9,65.9 L 156.2,64.3 L 157.6,63.9 L 158.9,61.9 L 158.0,60.0 L 159.2,58.2 L 160.9,59.1 L 160.9,57.4 L 163.2,57.0 L 162.6,55.1 L 163.7,54.1 L 161.9,53.4 L 160.7,51.4 L 161.2,50.0 L 160.7,48.9 L 161.0,47.3 L 163.2,47.0 L 161.8,45.1 L 165.7,39.3 L 167.1,38.5 L 170.0,38.5 L 174.7,33.9 L 180.5,32.4 L 182.1,29.7 L 182.1,28.6 L 179.4,26.7 L 180.0,25.2 L 186.3,27.7 L 186.7,30.2 L 187.9,31.5 L 189.0,32.2 L 191.5,32.2 L 193.3,33.9 L 196.3,33.1 L 198.1,33.3 L 199.0,32.2 L 200.6,31.7 L 200.8,30.6 L 203.0,29.9 L 207.6,29.3 L 209.0,30.1 L 210.9,30.1 L 212.3,29.9 L 213.6,28.5 L 215.2,28.5 L 215.7,29.3 L 218.2,28.5 L 218.7,29.5 L 219.5,29.5 L 220.9,28.2 L 221.7,28.5 L 224.6,26.8 L 226.3,26.8 L 226.7,27.5 L 225.9,28.6 L 227.0,30.5 L 226.7,32.7 L 228.6,35.4 L 226.7,36.7 L 225.9,40.8 L 224.8,42.1 L 225.0,43.7 L 227.7,44.2 L 228.7,45.5 L 231.1,45.5 L 232.9,46.7 L 233.3,48.5 L 235.0,44.8 L 237.1,42.8 L 238.4,42.8 L 238.8,41.6 L 240.1,41.2 L 248.5,44.7 L 251.1,44.2 L 252.5,45.8 L 254.4,45.5 L 257.9,43.1 L 259.1,44.8 L 257.2,45.1 L 256.2,48.1 L 257.1,49.0 L 259.2,49.3 L 261.9,49.0 L 262.4,47.8 L 264.0,46.7 L 266.9,39.7 L 264.6,37.2 L 266.4,34.3 L 265.3,32.7 L 266.4,31.6 L 266.4,30.2 L 266.2,29.2 L 264.0,27.8 L 263.7,26.5 L 264.6,24.7 L 266.7,23.8 L 266.4,22.9 L 267.4,22.0 Z" 
          fill="url(#mapLandGrad)" 
          stroke="#098B38" 
          stroke-width="2" 
          stroke-linejoin="round" 
          stroke-linecap="round" />
  </g>

  <!-- NETWORK PULSE HALOS -->
  <!-- Central Hub Pulsing Halo -->
  <circle cx="235" cy="140" r="26" fill="url(#hubPulseGrad)"/>
  <circle cx="235" cy="140" r="15" fill="none" stroke="#098B38" stroke-width="1" stroke-dasharray="3 3" opacity="0.7"/>

  <!-- Northern Hub Halo -->
  <circle cx="195" cy="52" r="16" fill="url(#hubBluePulse)"/>

  <!-- Western Hub Halo -->
  <circle cx="160" cy="85" r="16" fill="url(#hubBluePulse)"/>

  <!-- Southern Hub Halo -->
  <circle cx="202" cy="182" r="16" fill="url(#hubPulseGrad)"/>

  <!-- INTERCONNECTING NETWORK LINES -->
  <g stroke-linecap="round" stroke-linejoin="round">
    <!-- Major Arteries (Solid Brand Green) -->
    <line x1="235" y1="140" x2="202" y2="114" stroke="#098B38" stroke-width="2.4" filter="url(#glowFilter)"/>
    <line x1="202" y1="114" x2="160" y2="85" stroke="#098B38" stroke-width="2.2" filter="url(#glowFilter)"/>
    <line x1="235" y1="140" x2="242" y2="158" stroke="#098B38" stroke-width="2.4"/>
    <line x1="235" y1="140" x2="202" y2="182" stroke="#098B38" stroke-width="2.2"/>
    <line x1="202" y1="114" x2="195" y2="52" stroke="#098B38" stroke-width="2"/>

    <!-- Secondary Interconnected Mesh Lines (Accent Sky Blue, Dashed) -->
    <line x1="195" y1="52" x2="230" y2="75" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="230" y1="75" x2="265" y2="55" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="265" y1="55" x2="278" y2="85" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="278" y1="85" x2="235" y2="140" stroke="#64A8DA" stroke-width="2" stroke-dasharray="4 3"/>
    <line x1="235" y1="140" x2="258" y2="142" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="3 3"/>
    <line x1="160" y1="85" x2="195" y2="52" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="160" y1="85" x2="145" y2="105" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="3 3"/>
    <line x1="145" y1="105" x2="142" y2="138" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="142" y1="138" x2="202" y2="114" stroke="#64A8DA" stroke-width="1.6" stroke-dasharray="4 3"/>
    <line x1="142" y1="138" x2="142" y2="168" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="142" y1="168" x2="168" y2="188" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="168" y1="188" x2="202" y2="182" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="202" y1="182" x2="242" y2="158" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="142" y1="168" x2="132" y2="198" stroke="#64A8DA" stroke-width="1.8" stroke-dasharray="4 3"/>
    <line x1="132" y1="198" x2="168" y2="188" stroke="#64A8DA" stroke-width="1.6" stroke-dasharray="4 3"/>
    <line x1="160" y1="85" x2="235" y2="140" stroke="#64A8DA" stroke-width="1.4" stroke-dasharray="5 4" opacity="0.6"/>
  </g>

  <!-- GLOWING NETWORK NODES (Without city/state names) -->
  <!-- Central Hub Node -->
  <circle cx="235" cy="140" r="6.5" fill="#098B38" stroke="#FFFFFF" stroke-width="2.5" filter="url(#glowFilter)"/>
  <circle cx="235" cy="140" r="2.5" fill="#FFFFFF"/>

  <!-- Coastal Node -->
  <circle cx="242" cy="158" r="5" fill="#098B38" stroke="#FFFFFF" stroke-width="2"/>
  
  <!-- Eastern Port Node -->
  <circle cx="258" cy="142" r="4" fill="#64A8DA" stroke="#FFFFFF" stroke-width="1.5"/>

  <!-- Northern Industrial Node -->
  <circle cx="195" cy="52" r="5.5" fill="#64A8DA" stroke="#FFFFFF" stroke-width="2"/>

  <!-- Western Hub Node -->
  <circle cx="160" cy="85" r="5.5" fill="#64A8DA" stroke="#FFFFFF" stroke-width="2"/>

  <!-- Central Belt Node -->
  <circle cx="202" cy="114" r="5" fill="#098B38" stroke="#FFFFFF" stroke-width="2"/>

  <!-- North East Node -->
  <circle cx="278" cy="85" r="4.5" fill="#64A8DA" stroke="#FFFFFF" stroke-width="1.8"/>

  <!-- North Tip Node -->
  <circle cx="265" cy="55" r="4" fill="#64A8DA" stroke="#FFFFFF" stroke-width="1.5"/>

  <!-- Keonjhar Node -->
  <circle cx="230" cy="75" r="4" fill="#098B38" stroke="#FFFFFF" stroke-width="1.5"/>

  <!-- Bargarh Node -->
  <circle cx="145" cy="105" r="4" fill="#64A8DA" stroke="#FFFFFF" stroke-width="1.5"/>

  <!-- Balangir Node -->
  <circle cx="142" cy="138" r="4.5" fill="#64A8DA" stroke="#FFFFFF" stroke-width="1.8"/>

  <!-- Kalahandi Node -->
  <circle cx="142" cy="168" r="4" fill="#64A8DA" stroke="#FFFFFF" stroke-width="1.5"/>

  <!-- Southern Hub Node -->
  <circle cx="202" cy="182" r="5.5" fill="#098B38" stroke="#FFFFFF" stroke-width="2"/>

  <!-- Rayagada Node -->
  <circle cx="168" cy="188" r="4" fill="#64A8DA" stroke="#FFFFFF" stroke-width="1.5"/>

  <!-- South-Western Node -->
  <circle cx="132" cy="198" r="4.5" fill="#64A8DA" stroke="#FFFFFF" stroke-width="1.8"/>

  <!-- FLOATING PEOPLE ROLE AVATARS -->
  <!-- Corporate / Management near Central Hub -->
  <g transform="translate(210, 116)" filter="url(#badgeShadow)">
    <circle cx="12" cy="12" r="12" fill="#FFFFFF" stroke="#098B38" stroke-width="1.8"/>
    <text x="12" y="16.5" font-size="12" text-anchor="middle">👔</text>
  </g>

  <!-- IT / Tech / Operations near Western Hub -->
  <g transform="translate(155, 74)" filter="url(#badgeShadow)">
    <circle cx="12" cy="12" r="12" fill="#FFFFFF" stroke="#64A8DA" stroke-width="1.8"/>
    <text x="12" y="16.5" font-size="12" text-anchor="middle">👨‍💻</text>
  </g>

  <!-- Hospitality / Home Care near Southern Coastal Corridor -->
  <g transform="translate(210, 150)" filter="url(#badgeShadow)">
    <circle cx="12" cy="12" r="12" fill="#FFFFFF" stroke="#64A8DA" stroke-width="1.8"/>
    <text x="12" y="16.5" font-size="12" text-anchor="middle">👩‍🍳</text>
  </g>

  <!-- VERIFIED NETWORK BADGE -->
  <g transform="translate(75, 40)" filter="url(#badgeShadow)">
    <rect width="56" height="20" rx="10" fill="#FFFFFF" stroke="#098B38" stroke-width="1.2"/>
    <text x="28" y="14" font-family="'Poppins', sans-serif" font-size="8" font-weight="700" fill="#098B38" text-anchor="middle">✓ LIVE</text>
  </g>

  <!-- CONNECTING TAG PILL (Balanced & Aligned) -->
  <g transform="translate(55, 248)" filter="url(#badgeShadow)">
    <rect width="290" height="36" rx="18" fill="#098B38" stroke="#FFFFFF" stroke-width="1.5"/>
    <circle cx="22" cy="18" r="4.5" fill="#FFFFFF"/>
    <circle cx="22" cy="18" r="8.5" fill="none" stroke="#FFFFFF" stroke-width="1.2" opacity="0.6"/>
    <text x="156" y="23" font-family="'Poppins', sans-serif" font-size="12" font-weight="700" fill="#FFFFFF" text-anchor="middle" letter-spacing="0.3px">Connecting People Across Odisha</text>
  </g>
</svg>
          </div>
          <div class="hero-badge-pill hero-badge-2" id="heroBadge2" data-depth="38">⚡ Within 24-Hour Call Back</div>
        </div>
      </div>
    </div>
  </section>

  <!-- 3. ANIMATED COUNTERS STRIP -->
  <section class="counter-strip" aria-label="Key Milestones">
    <div class="container counter-grid">
      <div class="counter-card">
        <div class="counter-number" data-target="15400" data-suffix="+">15,400+</div>
        <div class="counter-label">Candidates Registered</div>
        <div class="counter-sub">Across 30 Districts</div>
      </div>
      <div class="counter-card">
        <div class="counter-number" data-target="1250" data-suffix="+">1,250+</div>
        <div class="counter-label">Businesses Served</div>
        <div class="counter-sub">Small Businesses &amp; Corporates</div>
      </div>
      <div class="counter-card">
        <div class="counter-number" data-target="3800" data-suffix="+">3,800+</div>
        <div class="counter-label">Households Helped</div>
        <div class="counter-sub">Maids, Cooks, Drivers, Pandits</div>
      </div>
      <div class="counter-card">
        <div class="counter-number" data-target="30" data-suffix="/30">30/30</div>
        <div class="counter-label">Odisha Districts</div>
        <div class="counter-sub">Complete State Coverage</div>
      </div>
    </div>
  </section>

  <!-- 4. WHO WE HELP (3 Cards) -->
  <section class="section section-alt">
    <div class="container">
      <div class="section-header">
        <span class="section-badge">Our Pillars</span>
        <h2>Who We Help Across Odisha</h2>
        <p>A single dedicated bridge built specifically for our state's businesses, youth, and households.</p>
      </div>

      <div class="cards-grid-3">
        <!-- Card 1: Job Seekers -->
        <div class="feature-card">
          <div class="feature-card-icon">💼</div>
          <h3>Job Seekers</h3>
          <p>Find genuine openings close to home. From back office and sales to customer support and commercial driving, get placed without paying consultation fees.</p>
          <a href="<?php echo esc_url(home_url('/services-job-seekers/')); ?>" class="btn btn-green">Find a Job &rarr;</a>
        </div>

        <!-- Card 2: Employers -->
        <div class="feature-card">
          <div class="feature-card-icon">🏢</div>
          <h3>Employers &amp; Businesses</h3>
          <p>Hire pre-screened local talent quickly. Save countless hours interviewing mismatched applicants—get reliable staff ready to join immediately.</p>
          <a href="<?php echo esc_url(home_url('/services-employers/')); ?>" class="btn btn-green">Hire Staff Fast &rarr;</a>
        </div>

        <!-- Card 3: Households -->
        <div class="feature-card">
          <div class="feature-card-icon">🏠</div>
          <h3>Households &amp; Families</h3>
          <p>Connect with trustworthy house maids, experienced cooks, verified drivers, and authentic pandits for sacred family pujas.</p>
          <a href="<?php echo esc_url(home_url('/services-customers/')); ?>" class="btn btn-green">Find Domestic Help &rarr;</a>
        </div>
      </div>
    </div>
  </section>

  <!-- 5. ROLES WE PLACE (Icon Grid - 11 Roles) -->
  <section class="section section-white">
    <div class="container">
      <div class="section-header">
        <span class="section-badge">Manpower Solutions</span>
        <h2>Roles We Place for Businesses</h2>
        <p>Pre-screened candidates ready to join offices, showrooms, retail chains, and logistics companies in Odisha.</p>
      </div>

      <div class="roles-grid">
        <div class="role-pill">
          <div class="role-pill-icon">💻</div>
          <span class="role-pill-name">Back Office</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">⌨️</div>
          <span class="role-pill-name">Data Entry</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">📊</div>
          <span class="role-pill-name">Accountant</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">📈</div>
          <span class="role-pill-name">Sales Executive</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🎧</div>
          <span class="role-pill-name">Telecaller</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">💬</div>
          <span class="role-pill-name">Customer Support</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🏢</div>
          <span class="role-pill-name">Receptionist</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">📎</div>
          <span class="role-pill-name">Office Peon</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🛡️</div>
          <span class="role-pill-name">Security Guard</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">📦</div>
          <span class="role-pill-name">Delivery Fleet</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🚗</div>
          <span class="role-pill-name">Commercial Drivers</span>
        </div>
      </div>

      <div style="text-align:center; margin-top: 2rem;">
        <a href="<?php echo esc_url(home_url('/services-employers/')); ?>" class="btn btn-green">Post Business Requirement &rarr;</a>
      </div>
    </div>
  </section>

  <!-- 6. HOUSEHOLD HELP (Icon Grid - 8 Services) -->
  <section class="section section-alt">
    <div class="container">
      <div class="section-header">
        <span class="section-badge">Trusted Home Services</span>
        <h2>Household Help You Can Rely On</h2>
        <p>Verified, dependable staff for your home, kitchen, caregiving, and spiritual ceremonies.</p>
      </div>

      <div class="roles-grid">
        <div class="role-pill">
          <div class="role-pill-icon">🧹</div>
          <span class="role-pill-name">House Maid</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">👨‍🍳</div>
          <span class="role-pill-name">Home Cook</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🚘</div>
          <span class="role-pill-name">Personal Driver</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">👶</div>
          <span class="role-pill-name">Babysitter</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">👵</div>
          <span class="role-pill-name">Elder Care</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🧼</div>
          <span class="role-pill-name">Deep Cleaner</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">📚</div>
          <span class="role-pill-name">Home Tutor</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">⚡</div>
          <span class="role-pill-name">Electrician</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🔧</div>
          <span class="role-pill-name">Plumber</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🛡️</div>
          <span class="role-pill-name">Security Guard</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🌱</div>
          <span class="role-pill-name">Gardener</span>
        </div>
        <div class="role-pill">
          <div class="role-pill-icon">🪔</div>
          <span class="role-pill-name">Pandit for Puja</span>
        </div>
      </div>

      <div style="text-align:center; margin-top: 2rem;">
        <a href="<?php echo esc_url(home_url('/services-customers/')); ?>" class="btn btn-green">Request Home Help Call Back &rarr;</a>
      </div>
    </div>
  </section>

  <!-- 7. HOW IT WORKS (4 STEPS) -->
  <section class="section section-white">
    <div class="container">
      <div class="section-header">
        <span class="section-badge">Simple Process</span>
        <h2>How Odiins Works</h2>
        <p>Connecting you with the right person in four simple, transparent steps.</p>
      </div>

      <div class="steps-grid">
        <div class="step-card">
          <div class="step-number">1</div>
          <div style="font-size:2rem; margin-bottom:0.5rem;">📝</div>
          <h4>Tell Us Your Need</h4>
          <p>Fill out our short 4-field form, send a WhatsApp message, or give us a quick call with your requirement.</p>
        </div>

        <div class="step-card">
          <div class="step-number">2</div>
          <div style="font-size:2rem; margin-bottom:0.5rem;">🔍</div>
          <h4>We Shortlist</h4>
          <p>Our local team screens matching profiles from our verified Odisha database to find candidates that fit your criteria.</p>
        </div>

        <div class="step-card">
          <div class="step-number">3</div>
          <div style="font-size:2rem; margin-bottom:0.5rem;">🤝</div>
          <h4>We Connect You</h4>
          <p>We arrange direct interaction or telephonic discussion so you can speak directly with the candidate or employer.</p>
        </div>

        <div class="step-card">
          <div class="step-number">4</div>
          <div style="font-size:2rem; margin-bottom:0.5rem;">✅</div>
          <h4>You Decide</h4>
          <p>No pressure, no long contracts. You make the final decision with complete clarity, transparency, and local support.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- 8. WHY CHOOSE US (6 BADGES) -->
  <section class="section section-alt">
    <div class="container">
      <div class="section-header">
        <span class="section-badge">The Odiins Advantage</span>
        <h2>Why Choose Us</h2>
        <p>Built by Odias, for Odisha. Here is what makes our platform the premier choice.</p>
      </div>

      <div class="badges-grid">
        <div class="why-badge">
          <div class="why-badge-icon">🏛️</div>
          <div class="why-badge-text">
            <h4>Odisha-Focused</h4>
            <p>100% committed to local employment and business growth across our state.</p>
          </div>
        </div>

        <div class="why-badge">
          <div class="why-badge-icon">⚡</div>
          <div class="why-badge-text">
            <h4>Fast Response</h4>
            <p>We connect with you within 24 hours to accelerate your hiring or job search.</p>
          </div>
        </div>

        <div class="why-badge">
          <div class="why-badge-icon">📞</div>
          <div class="why-badge-text">
            <h4>Personal Follow-up</h4>
            <p>Dedicated account managers who guide you through every step personally.</p>
          </div>
        </div>

        <div class="why-badge">
          <div class="why-badge-icon">✨</div>
          <div class="why-badge-text">
            <h4>Simple Process</h4>
            <p>No complex portals, no lengthy registrations—just short lead forms and quick calls.</p>
          </div>
        </div>

        <div class="why-badge">
          <div class="why-badge-icon">👥</div>
          <div class="why-badge-text">
            <h4>Local Team</h4>
            <p>On-ground presence in Bhubaneswar, Cuttack, and regional districts.</p>
          </div>
        </div>

        <div class="why-badge">
          <div class="why-badge-icon">🗣️</div>
          <div class="why-badge-text">
            <h4>Support in Your Language</h4>
            <p>Talk comfortably with our team in Odia, Hindi, or English anytime.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 9. ABOUT US SNIPPET -->
  <section class="section section-white">
    <div class="container">
      <div class="about-quote-card">
        <span class="section-badge">Our Roots &amp; Purpose</span>
        <h2 style="margin: 0.75rem 0 1rem 0; font-size:1.85rem;">Bridging the Talent &amp; Opportunity Gap Across Odisha</h2>
        <p style="font-size:1.1rem; color:var(--text-charcoal); line-height:1.7; margin-bottom:1.5rem;">
          "Odisha has talented people and growing businesses, but they don't always find each other. Odiins bridges that gap, and we work only in Odisha because we believe in growing our own state."
        </p>
        <div>
          <a href="<?php echo esc_url(home_url('/about-vision-mission/')); ?>" class="btn btn-green">Read Our Vision &amp; Mission &rarr;</a>
        </div>
      </div>
    </div>
  </section>

  <!-- 10. MEDIA SNIPPET ("We're Making News") -->
  <section class="section section-alt">
    <div class="container">
      <div class="section-header">
        <span class="section-badge">Press &amp; Updates</span>
        <h2>We're Making News</h2>
        <p>Featured in regional media and recognized for transforming manpower connections in Odisha.</p>
      </div>

      <div class="cards-grid-3">
        <!-- Media Card 1 -->
        <div class="media-card">
          <div class="media-card-img">
            <span style="font-size:3rem;">📰</span>
          </div>
          <div class="media-card-body">
            <span class="media-tag">Regional Press</span>
            <h4>Empowering Local Youth with Direct Career Opportunities</h4>
            <p>Featured in leading Odisha dailies for bridging the hiring gap for tier-2 businesses in Cuttack and Bhubaneswar.</p>
            <a href="<?php echo esc_url(home_url('/about-media/')); ?>" style="color:var(--primary-green); font-weight:600; font-size:0.88rem;">Read Coverage &rarr;</a>
          </div>
        </div>

        <!-- Media Card 2 -->
        <div class="media-card">
          <div class="media-card-img">
            <span style="font-size:3rem;">🏆</span>
          </div>
          <div class="media-card-body">
            <span class="media-tag">Recognition</span>
            <h4>Odisha MSME Employment Champion Citation</h4>
            <p>Recognized for supporting over 1,200 small enterprises with swift, verified recruitment solutions.</p>
            <a href="<?php echo esc_url(home_url('/about-media/')); ?>" style="color:var(--primary-green); font-weight:600; font-size:0.88rem;">View Citation &rarr;</a>
          </div>
        </div>

        <!-- Media Card 3 -->
        <div class="media-card">
          <div class="media-card-img">
            <span style="font-size:3rem;">🤝</span>
          </div>
          <div class="media-card-body">
            <span class="media-tag">Community Event</span>
            <h4>Annual Odisha Manpower &amp; Skill Development Meet</h4>
            <p>Keynote showcase on creating sustainable home help and skilled trades opportunities in our home state.</p>
            <a href="<?php echo esc_url(home_url('/about-media/')); ?>" style="color:var(--primary-green); font-weight:600; font-size:0.88rem;">View Highlights &rarr;</a>
          </div>
        </div>
      </div>

      <div style="text-align:center; margin-top:2.5rem;">
        <a href="<?php echo esc_url(home_url('/about-media/')); ?>" class="btn btn-green">View All Media &amp; Recognition &rarr;</a>
      </div>
    </div>
  </section>

  <!-- 11. DISTRICTS WE SERVE (Chips) -->
  <section class="section section-white">
    <div class="container" style="text-align:center;">
      <div class="section-header">
        <span class="section-badge">Statewide Reach</span>
        <h2>Districts We Serve in Odisha</h2>
        <p>Click on any district to connect with our regional desk and local talent pool.</p>
      </div>

      <div class="district-chips">
        <button class="district-chip active" data-district="Bhubaneswar">📍 Bhubaneswar</button>
        <button class="district-chip" data-district="Cuttack">📍 Cuttack</button>
        <button class="district-chip" data-district="Puri">📍 Puri</button>
        <button class="district-chip" data-district="Rourkela">📍 Rourkela</button>
        <button class="district-chip" data-district="Sambalpur">📍 Sambalpur</button>
        <button class="district-chip" data-district="Berhampur">📍 Berhampur</button>
        <button class="district-chip" data-district="Balasore">📍 Balasore</button>
        <button class="district-chip" data-district="Angul">📍 Angul</button>
        <button class="district-chip" data-district="Koraput">📍 Koraput</button>
      </div>

      <!-- Extra Districts Expandable View -->
      <div class="district-chips" id="extraDistricts" style="display:none; margin-top:1rem;">
        <button class="district-chip" data-district="Bhadrak">📍 Bhadrak</button>
        <button class="district-chip" data-district="Jajpur">📍 Jajpur</button>
        <button class="district-chip" data-district="Kendrapada">📍 Kendrapada</button>
        <button class="district-chip" data-district="Jagatsinghpur">📍 Jagatsinghpur</button>
        <button class="district-chip" data-district="Khordha">📍 Khordha</button>
        <button class="district-chip" data-district="Nayagarh">📍 Nayagarh</button>
        <button class="district-chip" data-district="Ganjam">📍 Ganjam</button>
        <button class="district-chip" data-district="Gajapati">📍 Gajapati</button>
        <button class="district-chip" data-district="Rayagada">📍 Rayagada</button>
        <button class="district-chip" data-district="Nabarangpur">📍 Nabarangpur</button>
        <button class="district-chip" data-district="Malkangiri">📍 Malkangiri</button>
        <button class="district-chip" data-district="Kalahandi">📍 Kalahandi</button>
        <button class="district-chip" data-district="Nuapada">📍 Nuapada</button>
        <button class="district-chip" data-district="Balangir">📍 Balangir</button>
        <button class="district-chip" data-district="Subarnapur">📍 Subarnapur</button>
        <button class="district-chip" data-district="Bargarh">📍 Bargarh</button>
        <button class="district-chip" data-district="Jharsuguda">📍 Jharsuguda</button>
        <button class="district-chip" data-district="Sundargarh">📍 Sundargarh</button>
        <button class="district-chip" data-district="Deogarh">📍 Deogarh</button>
        <button class="district-chip" data-district="Kendujhar">📍 Kendujhar</button>
        <button class="district-chip" data-district="Mayurbhanj">📍 Mayurbhanj</button>
      </div>

      <div style="margin-top: 1.5rem;">
        <button id="viewAllDistrictsBtn" class="btn btn-white btn-sm">View All 30 Districts of Odisha</button>
      </div>
    </div>
  </section>

  <!-- 12. TESTIMONIALS SLIDER (Hidden until real ones are added, as instructed) -->
  <section class="section section-alt" id="testimonialsSection" style="display: none;" aria-hidden="true">
    <div class="container">
      <div class="section-header">
        <span class="section-badge">Client Stories</span>
        <h2>What People in Odisha Say</h2>
      </div>
      <!-- Testimonials slider placeholder container -->
      <div class="testimonials-slider">
        <!-- Live verified reviews will be unhidden here -->
      </div>
    </div>
  </section>

  <!-- 13. LATEST 3 BLOG POSTS -->
  <section class="section section-alt">
    <div class="container">
      <div class="section-header">
        <span class="section-badge">Odisha Insights</span>
        <h2>Latest from Our Blog</h2>
        <p>Expert hiring tips, career guidance, and domestic management advice tailored for Odisha.</p>
      </div>

      <div class="cards-grid-3">
        <!-- Post 1 -->
        <article class="blog-card">
          <div class="blog-card-thumb">🏢</div>
          <div class="blog-card-content">
            <div class="blog-meta">
              <span>Hiring Tips</span>
              <span>•</span>
              <span>4 min read</span>
            </div>
            <h3>Hiring in Bhubaneswar: Top Skills Small Businesses are Looking for in 2026</h3>
            <p>Discover which competencies are driving growth in Bhubaneswar's burgeoning retail and IT sectors.</p>
            <a href="<?php echo esc_url(home_url('/blog-detail/')); ?>" style="color:var(--primary-green); font-weight:600; font-size:0.88rem;">Read Article &rarr;</a>
          </div>
        </article>

        <!-- Post 2 -->
        <article class="blog-card">
          <div class="blog-card-thumb">🏠</div>
          <div class="blog-card-content">
            <div class="blog-meta">
              <span>Household Help</span>
              <span>•</span>
              <span>3 min read</span>
            </div>
            <h3>How to Find a Verified, Trustworthy Cook or Maid in Cuttack &amp; Bhubaneswar</h3>
            <p>Essential checklist for Odisha families when bringing domestic help into their households.</p>
            <a href="<?php echo esc_url(home_url('/blog-detail/')); ?>" style="color:var(--primary-green); font-weight:600; font-size:0.88rem;">Read Article &rarr;</a>
          </div>
        </article>

        <!-- Post 3 -->
        <article class="blog-card">
          <div class="blog-card-thumb">📈</div>
          <div class="blog-card-content">
            <div class="blog-meta">
              <span>Odisha Job Market</span>
              <span>•</span>
              <span>5 min read</span>
            </div>
            <h3>5 Back-Office Roles Growing Rapidly Across Odisha's Tier-2 Cities</h3>
            <p>Why Rourkela, Sambalpur, and Balasore are witnessing strong demand for accounting and billing talent.</p>
            <a href="<?php echo esc_url(home_url('/blog-detail/')); ?>" style="color:var(--primary-green); font-weight:600; font-size:0.88rem;">Read Article &rarr;</a>
          </div>
        </article>
      </div>

      <div style="text-align:center; margin-top: 2.5rem;">
        <a href="<?php echo esc_url(home_url('/blogs/')); ?>" class="btn btn-green">Explore All Articles &rarr;</a>
      </div>
    </div>
  </section>

  <!-- 14. FAQ ACCORDION (5 Short Questions) -->
  <section class="section section-white">
    <div class="container">
      <div class="section-header">
        <span class="section-badge">Got Questions?</span>
        <h2>Frequently Asked Questions</h2>
        <p>Everything you need to know about working with Odiins in Odisha.</p>
      </div>

      <div class="accordion">
        <div class="accordion-item">
          <div class="accordion-header">
            <h4>1. Do job seekers have to pay any registration fee?</h4>
            <span class="accordion-icon">▼</span>
          </div>
          <div class="accordion-content">
            <p>No, registering as a job seeker on Odiins is completely free. We do not charge candidates any consultation or placement fees. Our mission is to connect skilled Odias with genuine opportunities without financial hurdles.</p>
          </div>
        </div>

        <div class="accordion-item">
          <div class="accordion-header">
            <h4>2. How quickly can a business hire staff through Odiins?</h4>
            <span class="accordion-icon">▼</span>
          </div>
          <div class="accordion-content">
            <p>Once you submit your requirement, our local team reviews our active candidate database and reaches back within 24 hours with matching, pre-screened candidate profiles ready for telephonic or in-person interviews.</p>
          </div>
        </div>

        <div class="accordion-item">
          <div class="accordion-header">
            <h4>3. How do you verify household help and drivers?</h4>
            <span class="accordion-icon">▼</span>
          </div>
          <div class="accordion-content">
            <p>We check government identity documents (Aadhaar, Voter ID, Driving License), verify local addresses, check previous work references, and facilitate personal interviews so you have peace of mind inviting help to your home.</p>
          </div>
        </div>

        <div class="accordion-item">
          <div class="accordion-header">
            <h4>4. In which districts does Odiins operate?</h4>
            <span class="accordion-icon">▼</span>
          </div>
          <div class="accordion-content">
            <p>Odiins covers all 30 districts of Odisha. While our primary hubs are in Bhubaneswar, Cuttack, Puri, Rourkela, Sambalpur, and Berhampur, we assist businesses and candidates across every district of our state.</p>
          </div>
        </div>

        <div class="accordion-item">
          <div class="accordion-header">
            <h4>5. Can I book a pandit for family pujas and Griha Pravesh?</h4>
            <span class="accordion-icon">▼</span>
          </div>
          <div class="accordion-content">
            <p>Yes! We connect you with experienced, Vedic-trained Odia Brahmins and pandits for Satyanarayan Puja, Griha Pravesh, Rudrabhishek, marriage rituals, and festive pujas across Odisha cities.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 15. FINAL CTA BANNER (Green Background, White Text) -->
  <section class="final-cta">
    <div class="container">
      <h2>Ready to Find the Right Fit in Odisha?</h2>
      <p>Whether you need a rewarding job, dependable manpower for your enterprise, or trusted help for your home, our local team is ready to assist you today.</p>
      <div class="final-cta-buttons">
        <a href="<?php echo esc_url(home_url('/services-job-seekers/')); ?>" class="btn btn-white btn-lg">💼 I Need a Job</a>
        <a href="<?php echo esc_url(home_url('/services-employers/')); ?>" class="btn btn-outline-white btn-lg">🏢 I Need Staff for My Business</a>
        <a href="<?php echo esc_url(home_url('/services-customers/')); ?>" class="btn btn-white btn-lg">🏠 I Need Help at Home</a>
      </div>
    </div>
  </section>

  <!-- GLOBAL FOOTER (4 Columns, Green Background, White Text, Blue Hover/Icons) -->

<?php get_footer(); ?>
